/* Cloudflare Turnstile for all enquiry forms.
   - The Turnstile script only loads once a visitor starts using a form (nothing is sent to Cloudflare's
     challenge servers on a normal page view).
   - Runs invisibly; a checkbox only appears if Cloudflare needs the visitor to confirm they are human.
   - The site key is filled in by _worker.js from the TURNSTILE_SITE_KEY variable in Cloudflare Pages.
     If it is not set, this file does nothing and the forms work without Turnstile. */
(function () {
  var SITE_KEY = "__TURNSTILE_SITE_KEY__";
  if (!SITE_KEY || SITE_KEY.indexOf("__") === 0) return;

  var forms = Array.prototype.slice.call(document.querySelectorAll("form#enquiry, form#cf, form#quoteForm"));
  if (!forms.length) return;

  var loading = null, widgets = new Map(), waiting = new Map();

  function loadScript() {
    if (loading) return loading;
    loading = new Promise(function (resolve, reject) {
      window.__jstTsReady = resolve;
      var s = document.createElement("script");
      s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=__jstTsReady";
      s.async = true; s.defer = true; s.onerror = reject;
      document.head.appendChild(s);
    });
    return loading;
  }

  function token(form) {
    var i = form.querySelector('input[name="cf-turnstile-response"]');
    return i && i.value ? i.value : "";
  }

  function render(form) {
    if (widgets.has(form)) return;
    var box = form.querySelector(".ts-box");
    if (!box) return;
    widgets.set(form, "pending");
    loadScript().then(function () {
      var id = window.turnstile.render(box, {
        sitekey: SITE_KEY,
        appearance: "interaction-only",
        theme: "light",
        action: form.id === "quoteForm" ? "quote" : "contact",
        callback: function () {
          var cb = waiting.get(form);
          if (cb) { waiting.delete(form); cb(); }
        },
        "before-interactive-callback": function () { box.style.margin = "4px 0 14px"; },
        "after-interactive-callback": function () { box.style.margin = ""; },
        "expired-callback": function () { window.turnstile.reset(id); }
      });
      widgets.set(form, id);
    }).catch(function () { widgets.delete(form); });
  }

  forms.forEach(function (form) {
    form.addEventListener("focusin", function () { render(form); });
    // Hold the submit until Turnstile has produced a token, then resubmit.
    form.addEventListener("submit", function (e) {
      if (token(form)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      if (typeof form.checkValidity === "function" && !form.checkValidity()) { form.reportValidity(); return; }
      var btn = form.querySelector('button[type="submit"]');
      if (btn && !btn.dataset.tsLabel) { btn.dataset.tsLabel = btn.innerHTML; btn.disabled = true; btn.textContent = "Checking..."; }
      render(form);
      waiting.set(form, function () {
        if (btn && btn.dataset.tsLabel) { btn.disabled = false; btn.innerHTML = btn.dataset.tsLabel; delete btn.dataset.tsLabel; }
        if (form.requestSubmit) form.requestSubmit(); else form.dispatchEvent(new Event("submit", { cancelable: true }));
      });
      // If nothing comes back (blocked script, no network), release the button after 15s.
      setTimeout(function () {
        if (waiting.has(form) && btn && btn.dataset.tsLabel) {
          waiting.delete(form); btn.disabled = false; btn.innerHTML = btn.dataset.tsLabel; delete btn.dataset.tsLabel;
          var note = form.querySelector(".ts-note");
          if (note) note.style.display = "block";
        }
      }, 15000);
    }, true);
  });

  // Tokens are single use: give the form a fresh one after every send attempt.
  window.jstTurnstileReset = function (form) {
    var id = widgets.get(form);
    if (id && id !== "pending" && window.turnstile) window.turnstile.reset(id);
  };
})();
