// JS Tech Installations: Cloudflare Pages advanced-mode worker.
// Handles POST /api/enquiry (website forms) and sends each enquiry to the inbox via Resend.
// Everything else is served as normal static files.
//
// Set in Cloudflare Pages > Settings > Variables and Secrets (Production and Preview):
//   RESEND_API_KEY  (secret, required)  Resend API key with "Sending access" for mail.jstechinstallations.co.uk
//   TO_EMAIL        (optional)          overrides DEFAULT_TO below
//   TURNSTILE_SITE_KEY   (plain text, optional) Turnstile site key. Shown to browsers.
//   TURNSTILE_SECRET_KEY (secret, optional)     Turnstile secret key. Turnstile is enforced only when BOTH are set.
//   FROM_EMAIL      (optional)          defaults to JS Tech Website <website@mail.jstechinstallations.co.uk>

const DEFAULT_TO = "info@jstechinstallations.co.uk";
const DEFAULT_FROM = "JS Tech Website <website@mail.jstechinstallations.co.uk>";
const ALLOWED_HOSTS = [/^(www\.)?jstechinstallations\.co\.uk$/, /(^|\.)js-tech-installations\.pages\.dev$/, /^localhost(:\d+)?$/, /^127\.0\.0\.1(:\d+)?$/];
const LIMITS = { name: 120, company: 160, email: 200, phone: 40, message: 5000 };

// Security headers are added here because Cloudflare does not reliably apply _headers in advanced mode.
const SECURITY_HEADERS = {
  "Strict-Transport-Security": "max-age=31536000",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), interest-cohort=()",
  "X-Frame-Options": "SAMEORIGIN",
};
const LONG_CACHE = /^\/(fonts\/|logo\.png$|email-logo\.png$|og-image\.jpg$|favicon|apple-touch-icon)/;

function withHeaders(res, pathname) {
  const out = new Response(res.body, res);
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) if (!out.headers.has(k)) out.headers.set(k, v);
  if (res.ok && LONG_CACHE.test(pathname)) out.headers.set("Cache-Control", "public, max-age=31536000");
  return out;
}

export default {
  async fetch(request, env) {
    const res = await route(request, env);
    return withHeaders(res, new URL(request.url).pathname);
  },
};

async function route(request, env) {
  {
    const url = new URL(request.url);
    if (url.pathname === "/api/enquiry") {
      if (request.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);
      try {
        return await handleEnquiry(request, env);
      } catch (err) {
        console.error("Enquiry handler error", err);
        return json({ ok: false, error: "Something went wrong. Please call or email us instead." }, 500);
      }
    }
    if (url.pathname === "/turnstile.js") {
      // Fill in the public site key so it lives in Cloudflare settings, not in the code.
      const asset = await env.ASSETS.fetch(request);
      if (!asset.ok) return asset;
      const body = (await asset.text()).replace("__TURNSTILE_SITE_KEY__", (env.TURNSTILE_SITE_KEY || "").replace(/[^\w-]/g, ""));
      return new Response(body, { headers: { "Content-Type": "application/javascript; charset=utf-8", "Cache-Control": "public, max-age=300" } });
    }
    return env.ASSETS.fetch(request);
  }
}

async function handleEnquiry(request, env) {
  // Only accept submissions from our own pages
  const origin = request.headers.get("Origin") || request.headers.get("Referer") || "";
  let originHost = "";
  try { originHost = new URL(origin).host; } catch (_) {}
  if (!ALLOWED_HOSTS.some((re) => re.test(originHost))) return json({ ok: false, error: "Forbidden" }, 403);

  const ct = request.headers.get("Content-Type") || "";
  let data = {};
  if (ct.includes("application/json")) data = await request.json();
  else { const fd = await request.formData(); for (const [k, v] of fd.entries()) if (typeof v === "string") data[k] = v; }

  // Honeypot: real visitors never see or fill this field. Pretend success so bots move on.
  if ((data.website || "").trim()) return json({ ok: true });

  // Cloudflare Turnstile check (only when both keys are configured)
  if (env.TURNSTILE_SITE_KEY && env.TURNSTILE_SECRET_KEY) {
    const tsToken = String(data["cf-turnstile-response"] || "");
    if (!tsToken) return json({ ok: false, error: "Security check missing. Please try again." }, 400);
    const vr = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ secret: env.TURNSTILE_SECRET_KEY, response: tsToken, remoteip: request.headers.get("CF-Connecting-IP") || undefined }),
    });
    const v = await vr.json().catch(() => ({}));
    if (!v.success) {
      console.warn("Turnstile failed", JSON.stringify(v["error-codes"] || []));
      return json({ ok: false, error: "Security check failed. Please try again." }, 403);
    }
  }

  const f = {};
  for (const k of Object.keys(LIMITS)) f[k] = String(data[k] || "").trim().slice(0, LIMITS[k]);
  const errors = [];
  if (!f.name) errors.push("name");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) errors.push("email");
  if (!f.message) errors.push("message");
  if (errors.length) return json({ ok: false, error: "Please check: " + errors.join(", ") }, 400);

  if (!env.RESEND_API_KEY) {
    console.error("RESEND_API_KEY is not set");
    return json({ ok: false, error: "Form is not configured. Please call or email us instead." }, 500);
  }

  let page = "";
  try { page = new URL(request.headers.get("Referer") || "").pathname; } catch (_) {}
  const when = new Date().toLocaleString("en-GB", { timeZone: "Europe/London", dateStyle: "full", timeStyle: "short" });
  const subject = `New enquiry from ${f.name}${f.company ? " at " + f.company : ""}`;

  const formName = { contact: "Contact form", quote: "Quote request" }[data.form] || "Website form";
  const site = new URL(request.url).origin;
  const logo = `${site}/email-logo.png`;
  const greyNA = '<span style="color:#9a9a9a;">Not given</span>';
  const rows = [
    ["Form", esc(formName)],
    ["Page", esc(page || "/")],
    ["Name", esc(f.name)],
    ["Company", f.company ? esc(f.company) : greyNA],
    ["Email", `<a href="mailto:${esc(f.email)}" style="color:#d4681c;text-decoration:underline;">${esc(f.email)}</a>`],
    ["Phone", f.phone ? `<a href="tel:${esc(f.phone.replace(/[^\d+]/g, ""))}" style="color:#161616;text-decoration:none;">${esc(f.phone)}</a>` : greyNA],
  ];
  const FONT = "font-family:Arial,Helvetica,sans-serif;";
  const html = `<!doctype html>
<html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light"><title>${esc(subject)}</title></head>
<body style="margin:0;padding:0;background:#f4f4f2;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${esc(f.name)}${f.company ? " at " + esc(f.company) : ""}: ${esc(f.message.slice(0, 110))}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f4f4f2;"><tr><td align="center" style="padding:28px 12px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#ffffff;border:1px solid #e1e0dd;border-radius:8px;">
  <tr><td align="center" style="padding:30px 24px 20px;">
    <img src="${logo}" width="112" height="56" alt="JS Tech Installations" style="display:block;border:0;width:112px;height:56px;">
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin-top:16px;"><tr><td style="${FONT}font-size:10px;font-weight:bold;letter-spacing:2px;text-transform:uppercase;color:#d4681c;background:#fdf1e8;border:1px solid #f3c7a6;border-radius:20px;padding:6px 16px;">New enquiry</td></tr></table>
  </td></tr>
  <tr><td style="height:3px;line-height:3px;font-size:0;background:#ea7a2c;">&nbsp;</td></tr>
  <tr><td style="padding:26px 30px 6px;">
    <h1 style="${FONT}margin:0;font-size:21px;line-height:1.3;color:#161616;">New enquiry from ${esc(f.name)}${f.company ? " at " + esc(f.company) : ""}</h1>
    <p style="${FONT}margin:6px 0 0;font-size:12.5px;color:#8a8a8a;">Website &bull; ${esc(when)}</p>
  </td></tr>
  <tr><td style="padding:14px 30px 4px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
${rows.map(([k, v], i) => `      <tr><td width="120" valign="top" style="${FONT}padding:13px 12px 13px 0;font-size:10.5px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#9a9a9a;${i ? "border-top:1px solid #ecebe8;" : ""}">${k}</td><td valign="top" style="${FONT}padding:12px 0;font-size:14px;line-height:1.45;color:#161616;${i ? "border-top:1px solid #ecebe8;" : ""}">${v}</td></tr>`).join("\n")}
    </table>
  </td></tr>
  <tr><td style="padding:6px 30px 0;"><div style="${FONT}border-top:1px solid #ecebe8;padding-top:20px;font-size:14px;line-height:1.65;color:#161616;white-space:pre-wrap;">${esc(f.message)}</div></td></tr>
  <tr><td style="padding:26px 30px 30px;">
    <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>
      <td style="background:#ea7a2c;border-radius:3px;"><a href="mailto:${esc(f.email)}?subject=${encodeURIComponent("Re: your enquiry to JS Tech Installations")}" style="${FONT}display:inline-block;padding:12px 22px;font-size:14px;font-weight:bold;color:#ffffff;text-decoration:none;white-space:nowrap;">Reply to ${esc(f.name.split(/\s+/)[0])}</a></td>
      ${f.phone ? `<td style="width:10px;">&nbsp;</td><td style="border:1px solid #d6d5d2;border-radius:3px;"><a href="tel:${esc(f.phone.replace(/[^\d+]/g, ""))}" style="${FONT}display:inline-block;padding:11px 20px;font-size:14px;font-weight:bold;color:#161616;text-decoration:none;white-space:nowrap;">Call ${esc(f.name.split(/\s+/)[0])}</a></td>` : ""}
    </tr></table>
  </td></tr>
  <tr><td align="center" style="${FONT}background:#fafaf8;border-top:1px solid #ecebe8;border-radius:0 0 8px 8px;padding:16px 24px;font-size:11.5px;color:#9a9a9a;">Sent by Franks Media &bull; <a href="https://franks-media.co.uk" style="color:#9a9a9a;text-decoration:none;">franks-media.co.uk</a></td></tr>
</table>
</td></tr></table>
</body></html>`;
  const text = `NEW ENQUIRY - JS Tech Installations\n\nForm: ${formName}\nPage: ${page || "/"}\nName: ${f.name}\nCompany: ${f.company || "Not given"}\nEmail: ${f.email}\nPhone: ${f.phone || "Not given"}\nReceived: ${when}\n\n${f.message}\n\nReply to this email to answer ${f.name} directly.\n\nSent by Franks Media - franks-media.co.uk`;

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: env.FROM_EMAIL || DEFAULT_FROM,
      to: [env.TO_EMAIL || DEFAULT_TO],
      reply_to: f.email,
      subject,
      html,
      text,
    }),
  });
  if (!res.ok) {
    console.error("Resend error", res.status, await res.text());
    return json({ ok: false, error: "Could not send right now. Please call or email us instead." }, 502);
  }
  return json({ ok: true });
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
}
